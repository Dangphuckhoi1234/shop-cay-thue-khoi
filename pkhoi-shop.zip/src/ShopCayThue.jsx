import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";

export default function ShopCayThue() {
  const [form, setForm] = useState({ username: "", password: "", service: "" });

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Đặt hàng thành công! Chúng tôi sẽ liên hệ với bạn sớm.");
    setForm({ username: "", password: "", service: "" });
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <h1 className="text-4xl font-bold text-center text-blue-600">P-Khôi - Shop Cày Thuê Roblox</h1>

      <section className="grid md:grid-cols-3 gap-4">
        {[
          { title: "Cày Blox Fruit", desc: "Cày từ level 0 đến 2450 chỉ trong 1 ngày." },
          { title: "Cày Pet Simulator X", desc: "Cày pet hiếm, kim cương full túi." },
          { title: "Cày Rank Combat Warriors", desc: "Lên top server nhanh chóng và an toàn." },
        ].map((item, index) => (
          <Card key={index} className="rounded-2xl shadow-lg">
            <CardContent className="p-4">
              <h2 className="text-xl font-semibold text-gray-800">{item.title}</h2>
              <p className="text-gray-600 mt-2">{item.desc}</p>
              <Button className="mt-4 w-full">Thuê Ngay</Button>
            </CardContent>
          </Card>
        ))}
      </section>

      <section className="mt-10">
        <h2 className="text-2xl font-bold mb-4 text-gray-700">Đặt Hàng Nhanh</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            placeholder="Tên tài khoản Roblox"
            value={form.username}
            onChange={(e) => setForm({ ...form, username: e.target.value })}
            required
          />
          <Input
            type="password"
            placeholder="Mật khẩu (chỉ nội bộ, bảo mật tuyệt đối)"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            required
          />
          <Textarea
            placeholder="Gói cày thuê bạn muốn (ví dụ: Blox Fruit full level)"
            value={form.service}
            onChange={(e) => setForm({ ...form, service: e.target.value })}
            required
          />
          <Button type="submit">Gửi Đơn Hàng</Button>
        </form>
      </section>

      <footer className="text-center text-sm text-gray-500 mt-12">
        © 2025 P-Khôi Shop. Liên hệ Zalo/Facebook để được tư vấn nhanh.
      </footer>
    </div>
  );
}
