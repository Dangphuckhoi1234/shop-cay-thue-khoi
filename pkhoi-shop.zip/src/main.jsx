import React from 'react'
import ReactDOM from 'react-dom/client'
import ShopCayThue from './ShopCayThue'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ShopCayThue />
  </React.StrictMode>
)
