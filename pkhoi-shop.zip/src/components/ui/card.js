export const Card = ({ children, className }) => <div className={className}>{children}</div>;
export const CardContent = ({ children, className }) => <div className={className}>{children}</div>;
export const Button = ({ children, className, ...props }) => <button className={className} {...props}>{children}</button>;
export const Input = (props) => <input {...props} className='border p-2 w-full rounded' />;
export const Textarea = (props) => <textarea {...props} className='border p-2 w-full rounded' />;
